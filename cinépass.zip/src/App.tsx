/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { AnimatePresence } from 'motion/react';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import MovieDetails from './pages/MovieDetails';
import SeatSelection from './pages/SeatSelection';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Profile from './pages/Profile';
import BookingConfirmation from './pages/BookingConfirmation';
import MovieListing from './pages/MovieListing';

function AnimatedRoutes() {
  const location = useLocation();

  return (
    <AnimatePresence mode="wait">
      <Routes location={location}>
        <Route path="/" element={<Home />} />
        <Route path="/movies" element={<MovieListing />} />
        <Route path="/movie/:id" element={<MovieDetails />} />
        <Route path="/book/:id" element={<SeatSelection />} />
        <Route path="/confirmation" element={<BookingConfirmation />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/profile" element={<Profile />} />
      </Routes>
    </AnimatePresence>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen flex flex-col font-sans">
        <Navbar />
        <main className="flex-1">
          <AnimatedRoutes />
        </main>
        <footer className="bg-slate-900 text-white py-12">
          <div className="max-w-7xl mx-auto px-4 text-center">
            <div className="text-2xl font-display font-bold tracking-tight mb-4">
              Ciné<span className="text-rose-500">Pass</span>
            </div>
            <p className="text-slate-400 text-sm max-w-md mx-auto">
              Your gateway to premium cinematic experiences. Book tickets for the latest blockbusters effortlessly.
            </p>
            <div className="mt-8 pt-8 border-t border-slate-800 text-slate-500 text-xs">
              © 2026 CinéPass. All rights reserved.
            </div>
          </div>
        </footer>
      </div>
    </BrowserRouter>
  );
}

