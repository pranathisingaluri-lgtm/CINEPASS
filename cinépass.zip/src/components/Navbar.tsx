import { Link, useNavigate } from 'react-router-dom';
import { Search, MapPin, User, LogIn, Menu, Film } from 'lucide-react';
import { useState } from 'react';

export default function Navbar() {
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const navigate = useNavigate();
  const [city, setCity] = useState('Mumbai');

  return (
    <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16 gap-4">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 flex-shrink-0">
            <div className="w-10 h-10 rounded-xl gradient-primary flex items-center justify-center text-white shadow-lg shadow-rose-100">
              <Film size={24} />
            </div>
            <span className="text-2xl font-display font-bold tracking-tight text-slate-900 hidden sm:block">
              Ciné<span className="text-rose-400">Pass</span>
            </span>
          </Link>

          {/* Search Bar */}
          <div className={`flex-1 max-w-xl transition-all duration-300 ${isSearchFocused ? 'scale-105' : ''}`}>
            <div className="relative group">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-hover:text-rose-400 transition-colors" size={18} />
              <input
                type="text"
                placeholder="Search for movies, events, plays..."
                className="w-full bg-slate-50 border-none rounded-full py-2.5 pl-10 pr-4 text-sm focus:ring-2 focus:ring-rose-400/20 focus:bg-white transition-all outline-none"
                onFocus={() => setIsSearchFocused(true)}
                onBlur={() => setIsSearchFocused(false)}
              />
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-4">
            <div className="hidden lg:flex items-center gap-1.5 text-sm font-medium text-slate-600 cursor-pointer hover:text-rose-400 transition-colors">
              <MapPin size={16} />
              <span>{city}</span>
            </div>
            
            <Link to="/login">
              <button className="hidden sm:flex items-center gap-2 px-5 py-2 rounded-full font-semibold text-sm transition-all gradient-primary text-white shadow-lg shadow-rose-100 hover:shadow-rose-200 hover:translate-y-[-1px] active:translate-y-0">
                <LogIn size={16} />
                Sign In
              </button>
            </Link>

            <Link to="/profile" className="p-2 rounded-full bg-slate-50 text-slate-600 hover:text-rose-400 hover:bg-rose-50 transition-all sm:hidden lg:block">
              <User size={20} />
            </Link>

            <button className="p-2 rounded-full bg-slate-50 text-slate-600 hover:bg-slate-100 transition-all block lg:hidden">
              <Menu size={20} />
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}
